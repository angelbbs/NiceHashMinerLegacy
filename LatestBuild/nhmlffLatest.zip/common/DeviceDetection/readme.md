DeviceDetection
Small project for identifying CPU(s) features and OpenCL (AMD) and CUDA (NVIDIA) GPUs.

TODO
Fork https://github.com/GPUOpen-LibrariesAndSDKs/OCL-SDK/ extract release and add as submodule