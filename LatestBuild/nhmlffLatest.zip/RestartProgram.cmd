@echo off
taskkill /F /IM MinerLegacyForkFixMonitor.exe
timeout 2
taskkill /F /IM NiceHashMinerLegacy.exe
timeout 2
start NiceHashMinerLegacy.exe
exit