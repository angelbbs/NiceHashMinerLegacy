@echo off
cls

SET RUN=FALSE
SET NOVISIBLE=TRUE

SET PLATFORM=%1
SET MMODE=%2
SET CUR_ALGO=%3
SET DEVLIST=%~4
SET MINERNAME=%5

echo %*
IF /I "%PLATFORM%"=="AMD" goto AMD_PARSING
IF /I "%PLATFORM%"=="NVIDIA" goto NVIDIA_PARSING
goto :end

rem *** AMD Section start ***
:AMD_PARSING
setlocal enableextensions enabledelayedexpansion
echo *********** AMD GPU-Tuning, Miner: !MINERNAME!, Algo: !CUR_ALGO!
for /f "tokens=1-14 delims=," %%i in (configs\overclock.cfg) do (
        set vendor=%%i
        set device=%%j
        set devicenum=%%k
        set miner=%%l
        set algo=%%m
        set gpuclock=%%n
        set gpuvoltage=%%o
        set memoryclock=%%p
        set memoryvoltage=%%q
        set temptarget=%%r
        set powerlimit=%%s
        set fanmin=%%t
         IF /I !fanmin!==!! (
          set fanmin=0
         )
        set fanmax=%%u
         IF /I !fanmax!==!! (
          set fanmax=3500
         )
        set fantarget=%%v
         IF /I !fantarget!==!! (
          set /a fantarget=!temptarget!-5
         )

    FOR %%G IN (%DEVLIST%) DO (
        set GPU=%%G
rem        echo GPU: !GPU!
rem        echo device: !device!
      IF /I !PLATFORM!==!vendor! (
        IF /I !GPU!==!devicenum! (
          IF /I !CUR_ALGO!==!algo! (
            IF /I !MINERNAME!==!miner! (
rem Not needed. Use GPU numbering with...
rem              call :check_intel !device!
              echo GPU#!device! - clock=!gpuclock!, GPU voltage=!gpuvoltage!, Memory clock=!memoryclock!, Memory voltage=!memoryvoltage!
              echo Fan min=!fanmin!, Fan max=!fanmax!, Fan target=!fantarget!, Temp target=!temptarget!, Power limit=!powerlimit!
              utils\OverdriveNTool.exe -ac!device! GPU_P#=!gpuclock!;!gpuvoltage! Mem_P#=!memoryclock!;!memoryvoltage! Fan_Min=!fanmin! Fan_Max=!fanmax! Fan_Target=!fantarget! Power_Temp=!temptarget! Power_Target=!powerlimit!
             )
          )
        )
      )
    )

 )
echo ***********
goto :end
rem *** AMD Section end ***


rem *** NVIDIA Section start ***
:NVIDIA_PARSING
setlocal enableextensions enabledelayedexpansion
echo *********** NVIDIA GPU-Tuning, Miner: !MINERNAME!, Algo: !CUR_ALGO!
for /f "tokens=1-11 delims=," %%i in (configs\overclock.cfg) do (
        set vendor=%%i
        set device=%%j
        set devicenum=%%k
        set miner=%%l
        set algo=%%m
        set gpuclock_o=%%n
        set memoryclock_o=%%o
        set powerlimit=%%p
        set voltage=%%q
        set temptarget=%%r
        set fanspeed=%%s

    FOR %%G IN (%DEVLIST%) DO (
        set GPU=%%G
rem        echo GPU: !GPU!
rem        echo device: !device!
      IF /I !PLATFORM!==!vendor! (
        IF /I !GPU!==!devicenum! (
          IF /I !CUR_ALGO!==!algo! (
           IF /I !MINERNAME!==!miner! (
            echo GPU#!GPU! - GPU clock offset: !gpuclock_o!, MemClock offset: !memoryclock_o!, PL: !powerlimit!, Volt: !voltage!
            echo Temp: !temptarget!, Fan: !fanspeed!
            utils\nvidiaInspector.exe -setBaseClockOffset:!devicenum!,0,!gpuclock_o! -setMemoryClockOffset:!devicenum!,0,!memoryclock_o! -lockVoltagePoint:!devicenum!,!voltage! -setPowerTarget:!devicenum!,!powerlimit! -setTempTarget:!devicenum!,0,!temptarget! -setFanSpeed:!devicenum!,!fanspeed!
           )
          )
        )
      )
    )

 )
echo ***********
goto :end
rem *** NVIDIA Section end ***

rem *** Check Intel Graphics ***
:check_intel
for /F "tokens=1* delims==" %%A IN ('WMIC Path Win32_VideoController get Name /Format:List ^| FIND "="') DO set "s=%%~B" & call :pars2

:pars2

set vd=%s%

for /F "tokens=1 delims= " %%i in ("%vd%") do (
   set wrd=%%i
   set intel=Intel(R)
   if /i !wrd!==!intel!) (
   echo Intel GPU found. Increasing GPU index
   set /a device=!device!+1
 )
)
exit /b


:end
timeout /t 2
